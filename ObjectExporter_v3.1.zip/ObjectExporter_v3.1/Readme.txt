IdentityIQ Object Exporter v3.1

Installation:
Copy the "sailpoint" folder (including the subfolders and class file) to the WEB-INF/classes/ folder in your IIQ installation.
Restart the application server.
Import the TaskDefinition_Export_XML.xml file using System Setup -> Import from File in the UI (or use iiq console).

Configuration:
Follow the User Guide in the doc folder.